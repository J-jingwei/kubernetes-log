from django.apps import AppConfig


class LogmanConfig(AppConfig):
    name = 'logman'
